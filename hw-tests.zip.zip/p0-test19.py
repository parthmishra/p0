#p0-test19.py
x = 2
y = 1
print x + y