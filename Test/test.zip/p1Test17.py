x = 55 if True else 0
x = 55 if (1==1) else 0
x = 55 if (---1==---1) else 0
x = 55 if input() else 0