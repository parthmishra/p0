x=[1]
# print x[0]
# print x[2]
# print x
