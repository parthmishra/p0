#p0-test15
input()+input()
print input()