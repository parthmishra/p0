print {1:55}
print not {1:55}
print {1:11} or {1:55}
print {1:11} and {1:55}
print {1:11, 2:22} == {2:22, 1:11}
print {1:11, 2:22} is {2:22, 1:11}