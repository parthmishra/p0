#p0-test12
x = 2
print -(1 + x)
# print x