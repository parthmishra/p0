print [1] == 1
print 0 != [0]