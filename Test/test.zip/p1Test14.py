print not 1
print 1 and 1
print 1 or 1
print 1 and 0
print 1 or 0
