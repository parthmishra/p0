#p0-test19.py
x = 2
y=x
z=y
# y = 1
# # print x + y
# x
# y