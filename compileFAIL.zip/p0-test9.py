#p0-test9
x=3+input()
print x