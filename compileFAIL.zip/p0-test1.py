#p0-test1
print(42)
