#p0-test14.py
print input()