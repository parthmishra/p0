a = 5 + input() +-6 + input()
# a =input()+-input()
print a