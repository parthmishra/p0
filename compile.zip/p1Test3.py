x=False
y=x+1
print y
