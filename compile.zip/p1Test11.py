x = ---input()+input()
y = input()
w = x and y
w = x or y
w = not(x and y)
w = not(x or y)