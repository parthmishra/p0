#p0-test2
input() #spaces
input() #tabs
x = 7 + 	14 #spaces and tabs
x =  x   +    x
8
x =   x    +	input()
print ((((((((x))))))))
print ((((((((input()))))))))
print           x+8
print      	(x+input())