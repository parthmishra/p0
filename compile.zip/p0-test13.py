#p0-test13.py
print -1