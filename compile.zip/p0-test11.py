#p0-test11
print input()+3