x = 1 + input()
y = x + x
z = y + y
w = z + z
a = w + w
b = a + a
c = b + b
d = c + c
e = d + d
f = x + y + z + w + a + b + c + d + e
print c