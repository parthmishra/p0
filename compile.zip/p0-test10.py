#p0-test10
print (3+4+5)