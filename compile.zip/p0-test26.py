# input()
# print input()
# print input()
# input() + input() + input()
# print input() + input() + input()
# 1
# print 1
# -1
# print -1
x = 10
w=4
# -x
# print x
# print -x
# 1 + 3
# print 1 + 3
# 1 + -5
# print 1 + -5
y = 5
# print y
z = 5
# print z
a = 15
# print a
b =  x+y+ z + input() + input() + a + x +y+w
print b
# print b
# c = x + y + --z + 7 + 8 + b
# print c
# print x + y + z + 7 + 8 + b