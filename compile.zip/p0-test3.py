#p0-test3
-input() + input()
