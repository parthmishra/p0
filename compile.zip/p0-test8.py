#p0-test8
x=5
y=x