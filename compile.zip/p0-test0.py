#p0-test0
print 1 + 2 + 3