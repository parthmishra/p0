x = 0 
y = 1
w = x and y
w = x or y
w = not(x and y)
w = not(x or y)