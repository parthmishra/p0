x=-input()
print -x+3
print x