#p0-test16
print input() + -input()