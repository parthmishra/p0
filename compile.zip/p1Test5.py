x=[1,2,3]
y=[4,5,6]
z=x+y
print z