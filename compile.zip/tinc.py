print ---input()
# w=input()
# w=-w
# w=-w
# w=-w
# print w