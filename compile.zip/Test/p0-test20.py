y = 1
x = ---y
print x