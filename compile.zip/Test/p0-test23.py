#Comment
input()
input()
x = 7 + 	14 
print ((((((((x))))))))
print ((((((((((((((((((((((((((((((( 4 )))))))))))))))))))))))))))))))
			# print           x+8
			# 	print      	(x+input())