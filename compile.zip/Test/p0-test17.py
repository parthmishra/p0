#p0-test17.py
x = input()
y = input()
z = x + y
print z