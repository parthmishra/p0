#p0-test2
input()